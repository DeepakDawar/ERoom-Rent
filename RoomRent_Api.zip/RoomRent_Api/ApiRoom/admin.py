from django.contrib import admin
from .models import Category,SubCategory,Location,Owner,Room,Customer,Booking
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(Location)
admin.site.register(Owner)
admin.site.register(Room)
admin.site.register(Customer)
admin.site.register(Booking)
