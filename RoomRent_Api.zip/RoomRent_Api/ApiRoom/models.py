from django.db import models
from django.utils import timezone
import datetime 

class Category(models.Model):
    category_name=models.CharField(max_length=100)
    def __str__(self):
        return self.category_name
    
    
    
class SubCategory(models.Model):
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    subcatgory_name=models.CharField(max_length=100)
    def __str__(self):
        return self.subcatgory_name    
    
    
    
class Location(models.Model):
    location_name=models.CharField(max_length=100)
    def __str__(self):
        return  self.location_name    


class Owner(models.Model):
    owner_name=models.CharField(max_length=100)
    owner_email=models.CharField(max_length=100)  
    owner_mobileno=models.CharField(max_length=100)
    owner_password=models.CharField(max_length=100)
    owner_permannent_add=models.CharField(max_length=50) 
    
  
    
    def __str__(self):
        return self.owner_name    
    

    
    
class Room(models.Model):
    
    owner=models.ForeignKey(Owner,on_delete=models.CASCADE)
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    subcategory=models.ForeignKey(SubCategory,on_delete=models.CASCADE)
    location=models.ForeignKey(Location,on_delete=models.CASCADE)
    room_title=models.CharField(max_length=100)
    room_description=models.CharField(max_length=500)
    room_facility=models.CharField(max_length=100)
    room_price=models.CharField(max_length=50)
    room_photo1= models.ImageField(upload_to="myimage")    
    room_photo2= models.ImageField(upload_to="myimage")    
    room_photo3= models.ImageField(upload_to="myimage")    
    
    def __str__(self):
        return "Title is"+self.room_title+ "Description is"+self.room_description+"Facility is"+self.room_facility+"Price is"+self.room_price
    
 
class Customer(models.Model):
    customer_name=models.CharField(max_length=100)
    customer_email=models.CharField(max_length=100)  
    customer_mobileno=models.CharField(max_length=100)
    customer_password=models.CharField(max_length=50)
    customer_permannent_address =models.CharField(max_length=100)  
    customer_looking_for=models.CharField(max_length=100,choices=(('Flat','Flat'),('Room','Room'),('Hostel','Hostel'),('PG','PG'))) 
    def __str__(self):
            return "Name is"+self.customer_name+"Email is"+self.customer_email+"Mobile No. is"+self.customer_mobileno+ "Password is" + self.customer_password+ "Permannent Address is"+self.customer_permannent_address+"Looking for"+self.customer_looking_for
      
      
class Booking(models.Model):
    booking_added_date=models.DateTimeField(auto_now_add=True)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    room=models.ForeignKey(Room,on_delete=models.CASCADE)
    def __str__(self):
        return "Booking is "+self.booking_date      