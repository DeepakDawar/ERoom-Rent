from django.contrib.auth.models import User
from rest_framework import serializers
from . models import Category,SubCategory,Location,Room,Customer,Booking,Owner


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['id','url','username','email','password']
        
        
        
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields='__all__'
        
        
class SubCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=SubCategory
        fields='__all__'
        
        
class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model=Location
        fields='__all__'       

class RoomSerializer(serializers.ModelSerializer):
    # category = CategorySerializer()
    # subcategory = SubcategorySerializer()   
    # Location = LocationSerializer()  
    # owner = OwnerSerializer()  
    class Meta:
        model = Room
        fields="__all__"
        

class Room1Serializer(serializers.ModelSerializer):
    category = CategorySerializer()
    subcategory = SubCategorySerializer()
    location = LocationSerializer()
    
    
    class Meta:
        model = Room
        fields = '__all__'
     
                        
                        
class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model=Customer
        fields='__all__'       
                                   

class OwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model=Owner
        fields='__all__'       
                            
        

class BookingSerializer(serializers.ModelSerializer):
    room = RoomSerializer(read_only=True)  # Assuming RoomSerializer is defined
    customer = CustomerSerializer(read_only=True)  # Assuming CustomerRegSerializer is defined

    class Meta:
        model = Booking
        fields = "__all__"






                                                            