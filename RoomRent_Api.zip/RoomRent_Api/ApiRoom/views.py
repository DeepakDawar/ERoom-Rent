from django.shortcuts import render
from django.contrib.auth.models import User
from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import action
from django.http import JsonResponse
from django.contrib import sessions
from django.shortcuts import get_object_or_404
import json


from ApiRoom.serializers import UserSerializer,CategorySerializer,SubCategorySerializer,CustomerSerializer,LocationSerializer,RoomSerializer,BookingSerializer,OwnerSerializer,Room1Serializer

from . models import Category,SubCategory,Location,Room,Customer,Booking,Owner

class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer


class CategoryViewSet(viewsets.ModelViewSet):
    queryset=Category.objects.all()
    serializer_class=CategorySerializer
    
class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset=SubCategory.objects.all()
    serializer_class=SubCategorySerializer
    
class LocationViewSet(viewsets.ModelViewSet):
    queryset=Location.objects.all()
    serializer_class=LocationSerializer    

class RoomViewSet(viewsets.ModelViewSet):
    queryset=Room.objects.all()
    serializer_class=Room1Serializer         
    
class CustomerViewSet(viewsets.ModelViewSet):
    queryset=Customer.objects.all()
    serializer_class=CustomerSerializer         

class OwnerViewSet(viewsets.ModelViewSet):
    queryset=Owner.objects.all()
    serializer_class=OwnerSerializer 
    
class BookingViewSet(viewsets.ModelViewSet):
    queryset=Booking.objects.all()
    serializer_class=BookingSerializer         




@api_view(['POST'])
def owner_login(request):
    if request.method == 'POST':
        mobile = request.data.get('mobileno')
        password = request.data.get('Password')
        print(mobile)
        print(password)
        
        # Use filter instead of get
        users = Owner.objects.filter(owner_mobileno=mobile, owner_password=password)
        print("users", users)
        
        if users.exists():  # Check if any users were found
            user = users.first()  # Get the first matching user
            
            # Pass the request in the serializer's context
            serializer = OwnerSerializer(user, context={'request': request})
            print(serializer)
            return Response(serializer.data)
        else:
            return Response("Invalid Login id and password")


@api_view(['POST'])
def viewownerroom(request):
    if request.method == 'POST':
        MOBILE = request.data.get('mobileno')
        user = Owner.objects.get(owner_mobileno=MOBILE)
        ROOMS = Room.objects.filter(owner=user)
        serializer = Room1Serializer(ROOMS, many=True, context={'request': request})
        print(serializer.data)
        return Response(serializer.data)

@api_view(['POST'])
def addownerroom(request):
    if request.method == 'POST':
        MOBILE = request.data.get('mobileno')
        owner1 = Owner.objects.get(owner_mobileno=MOBILE)

        category_id = request.data.get('category')
        category1 = Category.objects.get(id=category_id)

        subcategory_id = request.data.get('SubCategory')

        try:
            subcategory1 = SubCategory.objects.get(id=subcategory_id)
        except SubCategory.DoesNotExist:
            # Handle the case where the subcategory doesn't exist
            return Response({"error": "SubCategory with the given ID does not exist."}, status=status.HTTP_404_NOT_FOUND)

        location_id = request.data.get('location')
        location1 = Location.objects.get(id=location_id)

        Room.objects.create(   
            category=category1,
            subcategory=subcategory1,
            location=location1,
            room_title=request.data.get('room_title'),
            room_description=request.data.get('room_description'),     
            room_facility=request.data.get('room_facility'),
            room_price=request.data.get('room_price'),
            room_photo1=request.data.get('room_photo1'),
            room_photo2=request.data.get('room_photo2'),
            room_photo3=request.data.get('room_photo3'),
            owner=owner1,
        )
        print("Data saved successfully")
        return Response({"data": "Data saved successfully"})



@api_view(['POST'])
def editownerroom(request, pk):
    if request.method == 'POST':
        room2 = get_object_or_404(Room,pk=pk)
        print(room2)
        MOBILE = request.data.get('mobileno')
        owner1 = Owner.objects.get(owner_mobileno=MOBILE)

        roomid = request.data.get('Room_id')

        category1 = Category.objects.get(id=request.data.get('category'))
        subcategory1 = SubCategory.objects.get(id=request.data.get('subcategory'))
        location1 = Location.objects.get(id=request.data.get('location'))

        room2.category = category1
        room2.subcategory = subcategory1
        room2.location = location1
        room2.room_title = request.data.get('room_title')
        room2.room_description = request.data.get('room_description')
        room2.room_facility = request.data.get('room_facility')
        room2.room_price = request.data.get('room_price')
        
        # Handle file uploads properly
        if 'room_photo1' in request.data:
            room2.room_photo1 = request.data['room_photo1']
        if 'room_photo2' in request.data:
            room2.room_photo2 = request.data['room_photo2']
        if 'room_photo3' in request.data:
            room2.room_photo3 = request.data['room_photo3']
    

        room2.owner = owner1
        room2.save()

        return Response({"data": "data saved successfully"}, status=status.HTTP_200_OK)


@api_view(['POST'])
def bookingview(request):
    if request.method == 'POST':
        MOBILE = request.data.get('mobileno')
        try:
            # Retrieve the owner based on the provided owner_mobile
            owner_instance = Owner.objects.get(owner_mobileno=MOBILE)

            # Retrieve the rooms associated with the owner
            rooms = Room.objects.filter(owner=owner_instance)

            # Retrieve the bookings associated with those rooms
            bookings = Booking.objects.filter(room__in=rooms)  # Assuming 'room' is the ForeignKey field in BookingReg

            # Serialize the booking data
            booking_serializer = BookingSerializer(bookings, many=True, context={'request': request})

            # Combine the serialized data into a single response
            response_data = {
                'owner_name': owner_instance.owner_name,
                'bookings': booking_serializer.data
            }

            return Response(response_data)

        except Owner.DoesNotExist:
            return Response({'error': 'Owner not found'}, status=status.HTTP_404_NOT_FOUND)





        
        
        
@api_view(['GET'])
def Search_Room(request):
    if request.method == 'GET':
        category_id = request.query_params.get('category')
        subcategory_id = request.query_params.get('subcategory')
        location_id = request.query_params.get('location')
        queryset = Room.objects.all()
        
        if category_id:
            queryset = queryset.filter(category_id=category_id)  # Corrected field name
        if subcategory_id:
            queryset = queryset.filter(subcategory_id=subcategory_id)  # Corrected field name
        if location_id:
            queryset = queryset.filter(location_id=location_id)  # Corrected field name
        
        serializer = Room1Serializer(queryset, many=True, context={'request': request})
        
        if serializer.data:
            return Response(serializer.data)
        else:
            return Response("No rooms found", status=status.HTTP_404_NOT_FOUND)

        
        
@api_view(['GET'])
def show_subcatg(request):
    if request.method == 'GET':
        catg_id = request.query_params.get('catg_id')  
        print(catg_id,"idc")
        subcategories = SubCategory.objects.filter(category=catg_id)
        print(subcategories)
        serializer = SubCategorySerializer(subcategories, many=True)
        print(serializer.data)
        return Response(serializer.data)            
            
            
            
            
            
            
            
@api_view(['POST'])
def Customer_login(request):
    if request.method == 'POST':
      Email = request.data.get('customer_email')
      password = request.data.get('customer_password')

    if Email is not None and password is not None:
            print(Email)
            print(password)

            user = Customer.objects.filter(customer_email=Email, customer_password=password)
            print("user", user)
            if user:
                user = Customer.objects.get(customer_email=Email, customer_password=password)
                serializer = CustomerSerializer(user)
                print(serializer)
                return Response(serializer.data)
            else:
                return Response("Invalid Login id and password")
    else:
            return Response("Email and password fields are required")










@api_view(['POST'])
def Rbooking(request):
    if request.method == 'POST':
        room_id = request.data.get('room_id')
        customer_email = request.data.get('customer_email')

        try:
            room_instance = Room.objects.get(id=room_id)
            customer_instance = Customer.objects.get(customer_email=customer_email)
        except Room.DoesNotExist:
            return Response({"error": "Room not found"}, status=404)
        except Customer.DoesNotExist:
            return Response({"error": "Customer not found"}, status=404)

        # Create a new Booking instance and save it to the database
        booking_instance = Booking(room=room_instance, customer=customer_instance)
        booking_instance.save()

        # Serialize the created booking instance and return it in the response
        serializer = BookingSerializer(booking_instance, context={'request': request})
        return Response(serializer.data)

    return Response({"error": "Invalid request method"}, status=400)




from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view      
from .models import Room, Customer, Booking

@api_view(['POST'])
def Check_booking(request):
    if request.method == 'POST':
        room_id = request.data.get('room_id')
        customer_email = request.data.get('customer_email')

        try:
            room_instance = Room.objects.get(id=room_id)
            customer = Customer.objects.get(customer_email=customer_email)
        except Room.DoesNotExist:
            return Response("Room not found", status=status.HTTP_404_NOT_FOUND)
        except Customer.DoesNotExist:
            return Response("Customer not found", status=status.HTTP_404_NOT_FOUND)

        # Check if a booking already exists for the given room and customer
        existing_booking = Booking.objects.filter(room=room_instance, customer=customer).first()

        if existing_booking:
            return Response("Booking already exists", status=status.HTTP_400_BAD_REQUEST)
        
        # Create a new booking
        new_booking = Booking(customer=customer, room=room_instance)
        new_booking.save()
        
        return Response("Booking successful", status=status.HTTP_201_CREATED)
