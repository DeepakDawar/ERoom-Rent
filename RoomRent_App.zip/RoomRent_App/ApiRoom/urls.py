from django.urls import path
from . import views
from ApiRoom.views import EditRoomView

urlpatterns = [
    path('',views.index,name='index'),
    path('contact',views.contact,name='contact'),
    path('room',views.room,name='room'),
    path('about',views.about,name='about'),
    path('bookingtemp',views.bookingtemp,name='bookingtemp'),
    
   
    
    
    path('owner',views.owner_Registeration,name='owner_Registeration'),
    path('owner_login',views.owner_login,name='owner_login'),
    path('owner_Dashboard',views.owner_Dashboard,name='owner_Dashboard'),    
    
    
    

    
    
    
    
    path('view_room',views.view_room,name='view_room'),
    path('add_room',views.add_room,name='add_room'),
    path('EditRoom', EditRoomView.as_view(), name='EditRoom'),
    path('deleteroom',views.deleteroom,name='deleteroom'),
    path('booking',views.booking,name='booking'),
    path('searchroom', views.searchroom, name='searchroom'),
    # path('Show_subcatg',views.Show_subcatg,name='Show_subcatg'),
    path('apiroom/subcatg', views.Show_subcatg, name='subcatg'),
    
    
    path('booking_user', views.booking_user, name='booking_user'),
    
    
    
    
    
   
    path('customer_Registeration',views.customer_Registeration,name='customer_Registeration'),
    path('customer_loginbooking',views.customer_loginbooking,name='customer_loginbooking'),
    path('customer_loginindex',views.customer_loginindex,name='customer_loginindex'),
    path('Customer_logout',views.Customer_logout,name='Customer_logout'),
    
    
    
]
