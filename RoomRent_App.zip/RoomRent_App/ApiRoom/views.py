from django.shortcuts import render, redirect
import requests
from django.views import View
from django.http import HttpResponse

import requests
from requests.exceptions import RequestException


def index(request):
    sessionkey = request.session.get('session_email')

    try:
        category_response = requests.get('http://127.0.0.1:8000/Category/')
        location_response = requests.get('http://127.0.0.1:8000/Location/')

        category_response.raise_for_status()
        location_response.raise_for_status()

        category_data = category_response.json()
        location_data = location_response.json()

        return render(request, "apiroom/index.html", {'data': category_data, 'data1': location_data, 'session_email': sessionkey})

    except RequestException as e:
        return render(request, "apiroom/RoomSearch_error.html", {'message': f'Failed to fetch data: {str(e)}'})


def Show_subcatg(request):
    catg_id = request.GET.get('q')
    response = requests.get(
        'http://127.0.0.1:8000/show_subcatg', params={'catg_id': catg_id})
    tutor = response.json()
    return render(request, "apiroom/subcatg.html", {'data': tutor})


def room(request):
    return render(request, 'apiroom/room.html')


def about(request):
    return render(request, 'apiroom/about.html')


def contact(request):
    return render(request, 'apiroom/contact.html')


def bookingtemp(request):
    return render(request, 'apiroom/bookingtemp.html')


def searchroom(request):
    if request.method == "GET":
        category = request.GET.get('Category')
        subcategory = request.GET.get('SubCategory')
        location = request.GET.get('Location')
        response = requests.get('http://127.0.0.1:8000/Search_Room/', params={
            'category': category,
            'subcategory': subcategory,
            'location': location,
        })
        if "No rooms found" in response.text:
            return render(request, "apiroom/RoomSearch_error.html", {'message': 'No Rooms Found as per your matches'})
        else:
            room_data = response.json()
            return render(request, "room.html", {'room_data': room_data})
    return HttpResponse("Invalid request method")


def owner_Registeration(request):
    if request.method == "POST":
        postdata = {
            'owner_name': request.POST['owner_name'],
            'owner_email': request.POST['owner_email'],
            'owner_mobileno': request.POST['owner_mobileno'],
            'owner_password': request.POST['owner_password'],
            'owner_permannent_add': request.POST['owner_permannent_add'],

        }
        reponse = requests.post('http://127.0.0.1:8000/Owner/', data=postdata)
        return redirect('/owner_login')
    return render(request, 'apiroom/owner_Registeration.html')


def owner_login(request):
    if request.method == "POST":
        password = request.POST.get('password')
        mobileno = request.POST.get('mobileno')
        # mobileno = request.get('id')

        if password and mobileno:
            request.session['uname'] = request.POST["mobileno"]
            print(request.session['uname'])

            response = requests.post(
                'http://127.0.0.1:8000/login', data={'Password': password, 'mobileno': mobileno})
            data = response.json()
            return render(request, "apiroom\owner_Dashboard.html", {'data': data})
        else:
            return render(request, "apiroom\owner_login.html")
    return render(request, "apiroom\owner_login.html")


def owner_Dashboard(request):
    password = request.session.get('password')
    mobileno = request.session.get('mobileno')
    print(request.session.get('mobileno'))
    if password and mobileno:
        request.session['uname'] = request.POST["mobileno"]

        response = requests.get('http://127.0.0.1:8000/owner/')
        tutor = response.json()
        return render(request, "owner_Dashboard.html", {'res1': tutor, 'user_data': f"Password: {password}, Mobile No: {mobileno}"})
    else:
        return redirect('/owner_login')


def customer_Registeration(request):
    if request.method == "POST":
        postdata = {
            'customer_name': request.POST['customer_name'],
            'customer_email': request.POST['customer_email'],
            'customer_mobileno': request.POST['customer_mobileno'],
            'customer_password': request.POST['customer_password'],
            'customer_permannent_address': request.POST['customer_permannent_address'],
            'customer_looking_for':  request.POST['customer_looking_for'],
        }
        reponse = requests.post(
            'http://127.0.0.1:8000/Customer/', data=postdata)
        return redirect('/customer_loginbooking')
    return render(request, 'apiroom/customer_Registeration.html')




def customer_loginbooking(request):
    if request.method == "POST":
        password = request.POST.get('customer_password')
        Email = request.POST.get('customer_password')

        if password and Email:
            request.session['session_email'] = Email
            request.session['session_pwd'] = password

            # Send the data to the Customer_login view
            response = requests.post(
                'http://127.0.0.1:8000/Customer_login', data={'Email': Email, 'Password': password})

            if response.status_code == 200:
                # Handle a successful login
                return redirect("booking_user")
            else:
                # Handle an unsuccessful login (e.g., show an error message)
                return render(request, "apiroom/customer_loginbooking.html")

    return render(request, "apiroom/customer_loginbooking.html")





def customer_loginindex(request):
    if request.method == "POST":
        password = request.POST.get('customer_password')
        Email = request.POST.get('customer_email')

        if password and Email:
            request.session['session_email'] = Email
            request.session['session_pwd'] = password

            # Send the data to the Customer_login view
            response = requests.post(
                'http://127.0.0.1:8000/Customer_login', data={'Email': Email, 'Password': password})

            if response.status_code == 200:
                # Handle a successful login
                return redirect("index")
            else:
                # Handle an unsuccessful login (e.g., show an error message)
                return render(request, "apiroom/customer_loginindex.html")

    return render(request, "apiroom/customer_loginindex.html")


def Customer_logout(request):
    if 'session_email' in request.session:
        del request.session['session_email']
    if 'session_pwd' in request.session:
        del request.session['session_pwd']

    # Redirect to the main page or another appropriate page
    return redirect('index')


def view_room(request):
    if (request.session.has_key('uname')):
        mobileno = request.session.get('uname')
        print(mobileno)
        response = requests.post(
            'http://127.0.0.1:8000/viewownerroom', data={'mobileno': mobileno})
        tutor = response.json()
        print(tutor)
        return render(request, "apiroom/view_room.html", {'res1': tutor, 'sessionkey': request.session['uname']})
    else:
        return redirect('/owner_login')



def add_room(request):
    if (request.session.has_key('uname')):
        category_response = requests.get('http://127.0.0.1:8000/Category/')
        location_response = requests.get('http://127.0.0.1:8000/Location/')
        category_data = category_response.json()
        location_data = location_response.json()

        if request.method == "POST":
            mobileno = request.session.get('uname')

            postdata = {
                'mobileno': mobileno,
                'category': request.POST['category'],
                'SubCategory': request.POST['SubCategory'],
                'location': request.POST['location'],
                'room_title': request.POST['room_title'],
                'room_description': request.POST['room_description'],
                'room_facility': request.POST['room_facility'],
                'room_price': request.POST['room_price'],
            }
            files = {'room_photo1': request.FILES['room_photo1'],
                     'room_photo2': request.FILES['room_photo2'],
                     'room_photo3': request.FILES['room_photo3'],


                     }
            response = requests.post(
                'http://127.0.0.1:8000/addownerroom', data=postdata, files=files)
            print(response.status_code)
    else:

        print("not working")

        # if response.status_code == 201:
        #     return redirect('addroom')
        # else:
        #     error_message = "Failed to add room"
        #     print(response.content)
        #     return render(request, "desing/addroom.html", {'error_message': error_message})

    return render(request, "apiroom/add_room.html", {'data': category_data, 'data1': location_data, 'sessionkey': request.session['uname']})




class EditRoomView(View):
    template_name = "apiroom/Editroom.html"

    def get(self, request):
        category_response = requests.get('http://127.0.0.1:8000/Category/')
        location_response = requests.get('http://127.0.0.1:8000/Location/')
        category_data = category_response.json()
        location_data = location_response.json()
        room_id = request.GET.get('q')

        if room_id:
            url = f'http://127.0.0.1:8000/Room/{room_id}/'
            response = requests.get(url)

            if response.status_code == 200:
                property_data = response.json()
                print(property_data)
                return render(request, self.template_name, {'res1': property_data, 'data': category_data, 'data1': location_data})

        if 'uname' in request.session:
            return render(request, self.template_name)
        else:
            return redirect('/owner_login')

    def post(self, request):

        room_id = request.GET.get('q')

        if room_id:
            url = f'http://127.0.0.1:8000/Room/{room_id}/'
            response = requests.get(url)

            if response.status_code == 200:
                property_data = response.json()
        else:
            property_data = {}

        if 'uname' in request.session:
            mobileno = request.session.get('uname')

            postdata = {
            'mobileno': mobileno,
            'category': request.POST['category'],
            'subcategory': request.POST['subcategory'],
            'location': request.POST['location'],
            'room_title': request.POST['room_title'],
            'room_description': request.POST['room_description'],
            'room_facility': request.POST['room_facility'],
            # 'room_nearby': request.POST['room_nearby'],
            'room_price': request.POST['room_price'],
           }

            files = {
            'room_photo1': request.FILES['room_photo1'],
            'room_photo2': request.FILES['room_photo2'],
            'room_photo3': request.FILES['room_photo3']
            }

            url = f'http://127.0.0.1:8000/editownerroom/{room_id}/'

            response = requests.post(url, data=postdata, files=files)

            if response.status_code == 200:
                return render(request, self.template_name, {'message': 'Room updated successfully', 'res1': property_data, })
            else:

               return render(request, self.template_name, {'message': 'Failed to update room data', 'res1': property_data})
        else:
            return redirect('/owner_login')


def deleteroom(request):
    room_id = request.GET.get('q')
    print(room_id)
    if 'uname' in request.session:
        if request.method == "POST":
            # owner_mobile = request.session.get('uname')
            response = requests.delete(
                f'http://127.0.0.1:8000/Room/{room_id}/')
            return redirect('/view_room')
        return render(request, "apiroom/deleteroom.html")


def booking(request):
    if request.session.has_key('uname'):
        mobileno = request.session.get('uname')
        print(mobileno)

        response = requests.post(
            'http://127.0.0.1:8000/bookingview', data={'mobileno': mobileno})
        print(response.content)

        tutor = response.json()
        print(tutor, 'Booking data')

        return render(request, "apiroom/booking.html", {'aj': tutor, 'sessionkey': request.session['uname']})
    else:
        return redirect('/booking')


def booking_user(request):
    if 'session_email' in request.session and 'session_pwd' in request.session:
        customer_email = request.session.get('session_email')
        room_id = request.GET.get('q')

        if room_id:
            # Continue with your booking logic
            RoomData_response = requests.post(
                'http://127.0.0.1:8000/Rbooking', json={'customer_email': customer_email, 'room_id': room_id})
            RoomData = RoomData_response.json()
            return render(request, "apiroom/booking_success.html", {'url': RoomData, 'sessionkey': request.session['session_email']})
        else:
            # Handle the case where room_id is not provided
            return render(request, "apiroom/booking_error.html", {'error_message': 'Room ID not specified'})
    else:
        return redirect('customer_loginbooking')  # Fix the redirect URL here


# def login(request):
#     if request.method=="POST":
#         data={
#             request.POST['owner_email'],
#             request.POST['owner_mobileno'],

#         }
#         reponse=requests.post('http://127.0.0.1:8000/owner/', data)
#         data=reponse.json()
#     return render(request,'apiroom/Owner_Login.html')
